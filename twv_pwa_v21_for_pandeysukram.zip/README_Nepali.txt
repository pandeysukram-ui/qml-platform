TRADE WITH VIBES — GitHub + Google Drive setup (step by step)

Yo folder ma 6 ota file chha: index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png, icon-512-maskable.png

------------------------------------------------------------
STEP 1 — GitHub ma update garne (tapai ko link: https://pandeysukram-ui.github.io/qml-platform/)
------------------------------------------------------------
1. Yo zip lai Windows ma "Extract All" garnus.
2. github.com/pandeysukram-ui/qml-platform kholnus.
3. "Add file" -> "Upload files" thichnus.
4. Extract bhayeko folder ko 6 ota file (index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png, icon-512-maskable.png) tanera halnus.
   (README_Nepali.txt halnu pardaina.) index.html pahile ko v20 lai replace garchha, tyo thik ho.
5. Tala "Commit changes" thichnus. 1-2 minute pachhi https://pandeysukram-ui.github.io/qml-platform/ kholda tab ma "Suite v21" dekhincha.
   (Purano dekhiyo bhane Ctrl+F5 thichnus.)

!! Backup .json file GitHub ma kahile nahalnus. GitHub public hunchha, tapai ko data sabai le padhna sakchha.
   Backup .json Google Drive ma matra rakhnus.

------------------------------------------------------------
STEP 2 — Phone ma app banaune
------------------------------------------------------------
Phone ko Chrome ma https://pandeysukram-ui.github.io/qml-platform/ kholnus -> tin tipka (menu) -> "Add to Home screen" / "Install app".
Home screen ma Trade With Vibes ko icon aaucha, ra internet bina pani app khulchha.

------------------------------------------------------------
STEP 3 — Drive bata JSON load (duita tarika)
------------------------------------------------------------
TARIKA A (kehi setup nachahine, abhi nai kaam garchha):
  App ma "LOAD BACKUP .json" thichnus -> phone ko file picker ma "Drive" dekhincha -> backup .json chhannus.
  Ek palta load bhayepachi app le aafai yaad rakhchha, pheri kholda aafai load huncha.

TARIKA B (one-tap "DRIVE" button, ek palta setup chahincha):
  a) Google Drive ma backup .json upload garnus. File ma "Share" -> General access -> "Anyone with the link" (Viewer) -> Copy link.
     (Link bhayeko jo kasaile pani padhna sakchha. Tapai ko data private rakhna man chha bhane tarika A matra use garnus.)
  b) console.cloud.google.com kholnus (Gmail le login) -> tala "Select a project" -> "New project" -> naam: twv -> Create.
  c) Menu -> "APIs & Services" -> "Library" -> "Google Drive API" khojnus -> Enable.
  d) "APIs & Services" -> "Credentials" -> "Create credentials" -> "API key". Key copy garnus.
  e) Tyo key ma "Edit" thichnus:
       - Application restrictions: "Websites" -> https://pandeysukram-ui.github.io/* halnus
       - API restrictions: "Restrict key" -> Google Drive API matra -> Save
  f) index.html lai Notepad ma kholnus. Ctrl+F gari  TWV_DRIVE_KEY  khojnus. Tyo line ma '' ko biche ma key paste garnus:
        const TWV_DRIVE_KEY = 'AIza....';
     Save garera GitHub ma pheri upload (same naam, replace) garnus, ani sw.js ko CACHE number badalnus (twv-v21 -> twv-v22).
  g) App ma "DRIVE" button thichnus -> Drive ko link paste garnus. Yo link yaad rahancha.
     Pachhi har din 3 baje pachhi: Drive ma naya backup replace garnus -> app ma "DRIVE" thichnus -> load.
     Roj ko lagi: Drive ma file ma right-click -> "Manage versions" -> "Upload new version" garnus. Yesto garda link same rahancha. Naya file upload garyo bhane link badalinchha.
     Link galat bhaye app le aafai "Naya link halne?" sodhchha (computer ma Shift + DRIVE click le pani link badalna milcha).

------------------------------------------------------------
Update garne bela
------------------------------------------------------------
Naya index.html upload garesi sw.js ko 2nd line ma  const CACHE='twv-v21';  ko number badalnus (twv-v22 ...). Nabhae phone ma purano version dekhirahancha.
